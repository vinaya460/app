from flask import Flask, render_template, request
import sqlite3 as sql

app = Flask(__name__)


@app.route('/')
def home():
    return render_template('home.html')


@app.route('/curation')
def curate_job():
    return render_template('student.html')


@app.route('/curation', methods=['POST','GET'])
def curation():
    if request.method == 'POST':
        try:
            ResourceName = request.form['ResourceName']
           
            print(ResourceName)

            if ResourceName == "":
                ResourceName = "null"
           

            with sql.connect("database.db") as con:
                cur = con.cursor()

                cur.execute("INSERT INTO students (name) VALUES('anhyui')" )

                con.commit()
                msg = "Download Job Submitted"
        except:
            con.rollback()
            msg = "error in insert operation"

        finally:
            return render_template("result.html", msg=msg)
            con.close()



@app.route('/View//<int:page_num>')
def View(page):
    con = sql.connect("database.db")
    con.row_factory = sql.Row
    offset=page+5
    limit=page
    query="select * from students"+" offset "+offset+" limit "+limit

    cur = con.cursor()
    cur.execute(query)

    rows = cur.fetchall();
    return render_template("list.html", rows=rows)
       

@app.route('/data')
def data():
    user = request.args.get('node')
    user1 = request.args.get('want')
    if user != "":
        return user + " " + user1





if __name__ == '__main__':
    app.run()